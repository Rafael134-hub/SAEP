CREATE DATABASE IF NOT EXISTS saep_db
CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;

USE saep_db;


CREATE TABLE IF NOT EXISTS auth_user (
    id INT AUTO_INCREMENT PRIMARY KEY,
    username VARCHAR(150) NOT NULL UNIQUE,
    password VARCHAR(128) NOT NULL, -- Armazena hash PBKDF2
    first_name VARCHAR(30) NOT NULL,
    last_name VARCHAR(150) NOT NULL,
    email VARCHAR(254) NOT NULL,
    is_superuser TINYINT(1) NOT NULL DEFAULT 0,
    is_staff TINYINT(1) NOT NULL DEFAULT 0,
    is_active TINYINT(1) NOT NULL DEFAULT 1,
    date_joined DATETIME(6) NOT NULL
);


CREATE TABLE IF NOT EXISTS api_produto (
    id BIGINT AUTO_INCREMENT PRIMARY KEY,
    nome VARCHAR(255) NOT NULL,
    descricao LONGTEXT NULL,
    preco DECIMAL(10, 2) NOT NULL,
    qtd_atual INT NOT NULL,
    qtd_minima INT NOT NULL
);


CREATE TABLE IF NOT EXISTS api_movimentacao (
    id BIGINT AUTO_INCREMENT PRIMARY KEY,
    tipo VARCHAR(10) NOT NULL, -- Valores esperados: 'ENTRADA' ou 'SAIDA'
    quantidade INT NOT NULL,
    data_movimentacao DATETIME(6) NOT NULL,
    produto_id BIGINT NOT NULL,
    usuario_id INT NOT NULL,
    -- Definição de Chaves Estrangeiras com integridade referencial
    CONSTRAINT api_movimentacao_produto_fk FOREIGN KEY (produto_id) 
        REFERENCES api_produto (id) ON DELETE RESTRICT,
    CONSTRAINT api_movimentacao_usuario_fk FOREIGN KEY (usuario_id) 
        REFERENCES auth_user (id) ON DELETE RESTRICT
);


INSERT INTO auth_user (username, password, first_name, last_name, email, is_superuser, is_staff, is_active, date_joined) VALUES 
('admin_saep', 'pbkdf2_sha256$illustrativehash$admin', 'Administrador', 'Sistema', 'admin@loja.com', 1, 1, 1, NOW()),
('gerente_estoque', 'pbkdf2_sha256$illustrativehash$gerente', 'Maria', 'Oliveira', 'maria@loja.com', 0, 1, 1, NOW()),
('operador_caixa', 'pbkdf2_sha256$illustrativehash$operador', 'Carlos', 'Silva', 'carlos@loja.com', 0, 0, 1, NOW());

INSERT INTO api_produto (nome, descricao, preco, qtd_atual, qtd_minima) VALUES 
('Smartphone Samsung Galaxy S23', 'Processador Snapdragon 8 Gen 2, 256GB, Tela 6.1"', 4500.00, 15, 5),
('Notebook Dell Inspiron 15', 'Intel Core i7, 16GB RAM, SSD 512GB, Windows 11', 5200.00, 8, 3),
('Smart TV LG OLED 55"', '4K UHD, Tecnologia OLED evo, Inteligência Artificial ThinQ', 6100.00, 20, 4);

INSERT INTO api_movimentacao (tipo, quantidade, data_movimentacao, produto_id, usuario_id) VALUES 
('ENTRADA', 15, NOW() - INTERVAL 2 DAY, 1, 1), -- Entrada inicial do Galaxy S23 pelo admin
('SAIDA', 2, NOW() - INTERVAL 1 DAY, 2, 2),    -- Venda de Notebook pelo gerente
('SAIDA', 5, NOW(), 3, 3);                     -- Venda de TVs pelo operador