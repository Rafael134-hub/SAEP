import React, { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import { logout, getAuthApi } from '../../services/api/auth'; 

const Header = () => {
    const navigate = useNavigate();
    const [userName, setUserName] = useState('...');

    const handleNavigation = (path) => {
        navigate(path);
    };

    const handleLogout = () => {
        logout(); 
        navigate('/login'); 
    };

    useEffect(() => {
        const fetchUserInfo = async () => {
            const authApiInstance = getAuthApi(); 
            
            try {
                const response = await authApiInstance.get('user/info/'); 
                setUserName(response.data.first_name || response.data.username || 'Admin'); 
            } catch (error) {
                handleLogout(); 
            }
        };

        if (localStorage.getItem('accessToken')) {
            fetchUserInfo();
        } else {
            handleLogout(); 
        }
    }, []);

    return (
        <header className="flex justify-between items-center bg-pink-600 text-white p-4 shadow-lg sticky top-0 z-10">
            <h1 
                className="text-xl font-bold cursor-pointer hover:opacity-90 transition duration-150" 
                onClick={() => handleNavigation('/home')}
            >
                Sistema de Estoque SAEP
            </h1>

            <div className="flex items-center space-x-6">
                <nav className="hidden sm:flex space-x-4">
                    <button 
                        onClick={() => handleNavigation('/home')}
                        className="py-1 px-2 hover:bg-pink-700 rounded-md transition duration-150 text-sm font-medium"
                    >
                        Home
                    </button>
                    <button 
                        onClick={() => handleNavigation('/produtos')}
                        className="py-1 px-2 hover:bg-pink-700 rounded-md transition duration-150 text-sm font-medium"
                    >
                        Produtos
                    </button>
                    <button 
                        onClick={() => handleNavigation('/estoque')}
                        className="py-1 px-2 hover:bg-pink-700 rounded-md transition duration-150 text-sm font-medium"
                    >
                        Estoque
                    </button>
                </nav>

                <span className="text-sm text-white border-l border-pink-500 pl-4">
                    Bem-vindo(a), <span className="font-semibold">{userName}</span> 
                </span>
                
                <button 
                    onClick={handleLogout}
                    className="border-2 border-white px-3 py-1 text-white bg-red-500 rounded-lg hover:bg-red-600 transition duration-150 text-sm font-medium"
                >
                    Logout
                </button>
            </div>
        </header>
    );
};

export default Header;