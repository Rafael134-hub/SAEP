import React from 'react';
import { Routes, Route, Navigate } from 'react-router-dom';
import Login from './pages/login/login';
import Home from './pages/home/home';
import Produtos from './pages/produtos/produtos';
import Estoque from './pages/estoque/estoque';

const PrivateRoute = ({ children }) => {
    const isAuthenticated = localStorage.getItem('accessToken'); 
    return isAuthenticated ? children : <Navigate to="/login" />;
};

const App = () => {
    return (
        <Routes>
            <Route path="/login" element={<Login />} />
            <Route
                path="/home"
                element={<PrivateRoute><Home /></PrivateRoute>}
            />
            <Route
                path="/produtos"
                element={<PrivateRoute>
                  <Produtos/>
                </PrivateRoute>}
            />

            <Route
                path="/estoque"
                element={<PrivateRoute>
                  <Estoque/>
                </PrivateRoute>}
            />
            
            <Route path="/" element={<Navigate to="/home" />} />
        </Routes>
    );
};

export default App;