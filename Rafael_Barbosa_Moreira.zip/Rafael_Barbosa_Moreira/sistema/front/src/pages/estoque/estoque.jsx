import React, { useState, useEffect, useCallback } from 'react';
import Header from '../../components/header/header';
import Alert from '../../components/alert/alert';
import { getAuthApi } from '../../services/api/auth';
import { useNavigate } from 'react-router-dom';
import { z } from 'zod';

const movimentacaoSchema = z.object({
    produto_id: z.string().min(1, "Selecione um produto."),
    categoria_movimentacao: z.enum(['ENTRADA', 'SAIDA'], { message: "Selecione o tipo de movimentação." }),
    quantidade_movimentacao: z.coerce.number().int().min(1, "Quantidade deve ser 1 ou mais."),
    observacao_movimentacao: z.string().optional(),
});

const TabelaMovimentacao = ({
    movimentacoes,
    inputTermoBusca,
    filtroMovimentoAtivo,
    setInputTermoBusca,
    handleAplicarFiltro,
    handleLimparFiltro
}) => (
    <div className="overflow-x-auto bg-white shadow-lg rounded-xl">
        <div className="flex justify-between items-center p-4 border-b">
            <h3 className="text-xl font-bold">Histórico de Movimentações</h3>

            <div className="flex items-center space-x-2 w-full max-w-xs ml-4">
                <input 
                    type="text" 
                    placeholder="Filtrar por Produto..." 
                    value={inputTermoBusca} 
                    onChange={(e) => setInputTermoBusca(e.target.value)}
                    onKeyDown={(e) => e.key === 'Enter' && handleAplicarFiltro()}
                    className="border border-gray-300 rounded-lg p-2 flex-1 text-sm" 
                />
                
                <button 
                    onClick={handleAplicarFiltro}
                    className="px-3 py-2 text-white bg-blue-600 rounded-lg hover:bg-blue-700 transition duration-150 shadow-sm text-sm"
                    title="Aplicar Filtro"
                >
                    🔎
                </button>

                {filtroMovimentoAtivo && (
                    <button 
                        onClick={handleLimparFiltro}
                        className="p-2 text-gray-500 bg-gray-100 rounded-lg hover:bg-gray-200 transition duration-150"
                        title="Limpar Filtro"
                    >
                        <svg xmlns="http://www.w3.org/2000/svg" className="h-4 w-4" viewBox="0 0 20 20" fill="currentColor">
                            <path fillRule="evenodd" d="M4.293 4.293a1 1 0 011.414 0L10 8.586l4.293-4.293a1 1 0 111.414 1.414L11.414 10l4.293 4.293a1 1 0 01-1.414 1.414L10 11.414l-4.293 4.293a1 1 0 01-1.414-1.414L8.586 10 4.293 5.707a1 1 0 010-1.414z" clipRule="evenodd" />
                        </svg>
                    </button>
                )}
            </div>
        </div>
        
        <table className="min-w-full divide-y divide-gray-200">
            <thead className="bg-gray-50">
                <tr>
                    <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Data (7.1.3)</th>
                    <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Produto</th>
                    <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Tipo</th>
                    <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Qtd</th>
                    <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Responsável (7.1.3)</th>
                </tr>
            </thead>
            <tbody className="bg-white divide-y divide-gray-200">
                {movimentacoes.map(m => (
                <tr key={m.id}>
                    <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">{new Date(m.data_movimentacao).toLocaleDateString()}</td>
                    <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-900">{m.produto_nome}</td>
                    <td className={`px-6 py-4 whitespace-nowrap text-sm font-bold ${m.categoria_movimentacao === 'ENTRADA' ? 'text-green-600' : 'text-red-600'}`}>
                    {m.categoria_movimentacao}
                    </td>
                    <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">{m.quantidade_movimentacao}</td>
                    <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">{m.usuario_nome || 'N/A'}</td> 
                </tr>
                ))}
            </tbody>
        </table>
    </div>
);


const Estoque = () => {
    const navigate = useNavigate();
    const [produtos, setProdutos] = useState([]);
    const [movimentacoes, setMovimentacoes] = useState([]);
    const [loading, setLoading] = useState(true);
    const [formErrors, setFormErrors] = useState({});
    const [alertaEstoque, setAlertaEstoque] = useState(null); 
    const [formData, setFormData] = useState({ 
        produto_id: '', 
        categoria_movimentacao: 'ENTRADA', 
        quantidade_movimentacao: 1,
        observacao_movimentacao: ''
    });

    const [inputTermoBusca, setInputTermoBusca] = useState(''); 
    const [filtroMovimentoAtivo, setFiltroMovimentoAtivo] = useState(''); 

    const produtoSelecionado = produtos.find(p => p.id === parseInt(formData.produto_id));
    
    const fetchData = useCallback(async (termoFiltro = '') => {
        setLoading(true); 
        try {
            const authApi = getAuthApi();

            const prodResponse = await authApi.get('produtos/'); 
            setProdutos(prodResponse.data);

            let movUrl = 'movimentacoes/';
            if (termoFiltro && termoFiltro.trim() !== '') {
                movUrl = `movimentacoes/?search=${termoFiltro}`;
            }

            const movResponse = await authApi.get(movUrl);
            setMovimentacoes(movResponse.data);
        } catch (error) {
            console.error("Erro ao carregar dados:", error);
        } finally {
            setLoading(false);
        }
    }, []);

    useEffect(() => {
        fetchData(filtroMovimentoAtivo);
    }, [fetchData, filtroMovimentoAtivo]);

    const handleChange = (e) => {
        const { name, value } = e.target;
        setFormData({ ...formData, [name]: value });
        setFormErrors({});
        setAlertaEstoque(null);
    };

    const handleAplicarFiltro = () => {
        setFiltroMovimentoAtivo(inputTermoBusca);
    };

    const handleLimparFiltro = () => {
        setInputTermoBusca('');
        setFiltroMovimentoAtivo(''); 
    };

    const handleMovimentacao = async (e) => {
        e.preventDefault();
        setFormErrors({});
        setAlertaEstoque(null);
            
        const authApi = getAuthApi(); 
        
        try {
            const validatedData = movimentacaoSchema.parse(formData);

            const payload = {
                produto: validatedData.produto_id, 
                categoria_movimentacao: validatedData.categoria_movimentacao,
                quantidade_movimentacao: parseInt(validatedData.quantidade_movimentacao), 
                observacao_movimentacao: validatedData.observacao_movimentacao,
            };

            const response = await authApi.post('movimentacoes/', payload);

            if (response.data.alerta_estoque) {
                setAlertaEstoque(response.data.alerta_estoque); 
                window.alert(response.data.alerta_estoque); 
            }

            setFormData({ produto_id: '', categoria_movimentacao: 'ENTRADA', quantidade_movimentacao: 1, observacao_movimentacao: '' });

            fetchData(filtroMovimentoAtivo); 
            
        } catch (err) {
            if (err instanceof z.ZodError) {
                const newErrors = err.errors.reduce((acc, current) => {
                    acc[current.path[0]] = current.message;
                    return acc;
                }, {});
                setFormErrors(newErrors);
            } else if (err.response && err.response.data.quantidade_movimentacao) {
                setFormErrors({ quantidade_movimentacao: err.response.data.quantidade_movimentacao[0] });
            } else {
                console.error("Erro ao registrar:", err);
                setFormErrors({ global: "Erro ao registrar. Tente novamente." });
            }
        }
    };

    const MovimentacaoForm = () => (
        <div className="bg-white p-6 rounded-xl shadow-lg h-full">
            <h3 className="text-xl font-bold mb-4">Registrar Entrada/Saída (7.1.2)</h3>
            <form onSubmit={handleMovimentacao} className="space-y-4">
            {formErrors.global && <Alert message={formErrors.global} type="error" className="mb-4" />}
                {alertaEstoque && <Alert message={alertaEstoque} type="stock-alert" className="mb-4" />}
            
            <div>
                <label className="block text-sm font-medium text-gray-700">Produto</label>
                <select name="produto_id" value={formData.produto_id} onChange={handleChange} className="w-full mt-1 border border-gray-300 rounded-lg p-2">
                <option value="">Selecione um produto</option>
                {produtos.map(p => (
                    <option key={p.id} value={p.id}>{p.nome_produto} (Atual: {p.estoque_atual_produto})</option>
                ))}
                </select>
                {formErrors.produto_id && <p className="text-xs text-red-500 mt-1">{formErrors.produto_id}</p>}
            </div>

            {produtoSelecionado && (
                <div className="p-3 bg-blue-50 border border-blue-200 rounded-md text-sm font-semibold">
                Estoque Atual: <span className="text-blue-700">{produtoSelecionado.estoque_atual_produto} {produtoSelecionado.unidade_medida_produto}</span>
                {produtoSelecionado.estoque_atual_produto <= produtoSelecionado.estoque_minimo_produto && 
                    <span className="ml-2 text-red-600">(Estoque Baixo!)</span>
                }
                </div>
            )}

            <div>
                <label className="block text-sm font-medium text-gray-700">Tipo</label>
                <select name="categoria_movimentacao" value={formData.categoria_movimentacao} onChange={handleChange} className="w-full mt-1 border border-gray-300 rounded-lg p-2">
                <option value="ENTRADA">ENTRADA</option>
                <option value="SAIDA">SAÍDA</option>
                </select>
                {formErrors.categoria_movimentacao && <p className="text-xs text-red-500 mt-1">{formErrors.categoria_movimentacao}</p>}
            </div>

            <div>
                <label className="block text-sm font-medium text-gray-700">Quantidade</label>
                <input type="number" name="quantidade_movimentacao" min="1" value={formData.quantidade_movimentacao} onChange={handleChange} 
                className="w-full mt-1 border border-gray-300 rounded-lg p-2" />
                {formErrors.quantidade_movimentacao && <p className="text-xs text-red-500 mt-1">{formErrors.quantidade_movimentacao}</p>}
            </div>
            
            <div>
                <label className="block text-sm font-medium text-gray-700">Observação (Opcional)</label>
                <textarea name="observacao_movimentacao" value={formData.observacao_movimentacao} onChange={handleChange} 
                className="w-full mt-1 border border-gray-300 rounded-lg p-2" rows="2" />
            </div>

            <button type="submit" className="w-full py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700 transition duration-150 shadow-md">
                Registrar Movimentação
            </button>
            </form>
        </div>
    );

    return (
        <div className="min-h-screen bg-gray-50">
            <Header />
            <div className="max-w-7xl mx-auto p-4 sm:p-6 lg:p-8">
                <button onClick={() => navigate('/home')} className="mb-4 text-blue-600 hover:text-blue-800 font-semibold flex items-center">&larr; Voltar para Home</button>
                <h2 className="text-3xl font-bold text-gray-800 mb-6">Gestão de Estoque</h2>

                {loading ? (
                    <p className="text-gray-500">Carregando dados de estoque...</p>
                ) : (
                    <div className="grid grid-cols-1 lg:grid-cols-3 gap-8 items-start">
                    <div className="lg:col-span-1">
                        <MovimentacaoForm />
                    </div>
                    <div className="lg:col-span-2">
                        <TabelaMovimentacao 
                            movimentacoes={movimentacoes}
                            inputTermoBusca={inputTermoBusca}
                            filtroMovimentoAtivo={filtroMovimentoAtivo}
                            setInputTermoBusca={setInputTermoBusca}
                            handleAplicarFiltro={handleAplicarFiltro}
                            handleLimparFiltro={handleLimparFiltro}
                        />
                    </div>
                    </div>
                )}
            </div>
        </div>
    );
};

export default Estoque;