// src/pages/Produtos.jsx

import React, { useState, useEffect, useCallback } from 'react';
import { useNavigate } from 'react-router-dom';
import { z } from 'zod';
// ⚠️ ATENÇÃO: Se você usou o ProtectedLayout, remova esta linha:
// import Header from '../../components/header/header'; 
import Alert from '../../components/alert/alert';
import { getAuthApi } from '../../services/api/auth';
import Header from '../../components/header/header';

// --- Esquema de Validação Zod (Inalterado) ---
const produtoSchema = z.object({
    nome_produto: z.string().min(3, "Nome deve ter pelo menos 3 caracteres."),
    descricao_produto: z.string().optional(),
    estoque_minimo_produto: z.coerce.number().int().min(1, "O estoque mínimo deve ser 1 ou mais."),
    unidade_medida_produto: z.string().min(1, "Unidade de medida é obrigatória."),
    estoque_atual_produto: z.coerce.number().int().min(0, "O estoque atual não pode ser negativo.").optional(),
});

// --- Componente Modal/Form (Inalterado, exceto pela chamada refetch) ---
const ProdutoFormModal = ({ isOpen, onClose, produtoData, refetch }) => {
    const [formData, setFormData] = useState(produtoData || {});
    const [errors, setErrors] = useState({});
    const isEdit = !!produtoData;

    useEffect(() => {
        const defaultValues = { 
            nome_produto: '', 
            descricao_produto: '', 
            estoque_minimo_produto: 1, 
            unidade_medida_produto: 'unidade',
            estoque_atual_produto: 0, 
        };
        setFormData(produtoData ? { ...produtoData } : defaultValues);
        setErrors({});
    }, [produtoData, isOpen]);

    if (!isOpen) return null;

    const handleChange = (e) => {
        const { name, value, type } = e.target;
        setFormData(prev => ({
            ...prev,
            [name]: type === 'number' ? parseInt(value, 10) || 0 : value
        }));
    };

    const handleSubmit = async (e) => {
        e.preventDefault();
        const authApi = getAuthApi();

        try {
            let validatedData = isEdit ? 
                produtoSchema.omit({ estoque_atual_produto: true }).parse(formData) : 
                produtoSchema.parse(formData);

            if (isEdit) {
                delete validatedData.estoque_atual_produto; 
                await authApi.put(`produtos/${produtoData.id}/`, validatedData); 
            } else {
                await authApi.post('produtos/', validatedData); 
            }

            refetch(); // Chamada de refetch após salvar/editar
            onClose();
        } catch (err) {
            console.error('Erro ao salvar produto:', err);
            // ... (lógica de tratamento de erro)
            if (err instanceof z.ZodError) {
                 const newErrors = err.errors.reduce((acc, current) => {
                     acc[current.path[0]] = current.message;
                     return acc;
                 }, {});
                 setErrors(newErrors);
            } else if (err.response && err.response.status === 401) {
                setErrors({ global: "Sessão expirada. Por favor, faça login novamente." });
                localStorage.removeItem('accessToken');
                localStorage.removeItem('refreshToken');
            } else if (err.response && err.response.data) {
                if (err.response.data.nome_produto) {
                    setErrors({ nome_produto: "Este nome de produto já existe." });
                } else {
                    const backendErrors = Object.entries(err.response.data).reduce((acc, [key, value]) => {
                        acc[key] = Array.isArray(value) ? value.join(', ') : value;
                        return acc;
                    }, {});
                    setErrors(backendErrors);
                }
            } else {
                setErrors({ global: "Erro ao salvar. Verifique sua conexão ou tente novamente." });
            }
        }
    };

    return (
        <div className="fixed inset-0 bg-black bg-opacity-50 flex justify-center items-center z-50">
            <div className="bg-white p-8 rounded-xl w-full max-w-lg shadow-2xl">
                <h3 className="text-2xl font-bold mb-6 text-gray-800">{isEdit ? 'Editar Produto' : 'Novo Produto'}</h3>
                {errors.global && <Alert message={errors.global} type="error" className="mb-4" />}
                <form onSubmit={handleSubmit} className="space-y-4">
                    {/* ... (campos do formulário) ... */}
                    <div>
                        <label htmlFor="nome_produto" className="block text-sm font-medium text-gray-700">Nome do Produto</label>
                        <input type="text" name="nome_produto" id="nome_produto"
                            value={formData.nome_produto || ''}
                            onChange={handleChange}
                            className="mt-1 block w-full border border-gray-300 rounded-md shadow-sm p-2"
                        />
                        {errors.nome_produto && <p className="text-red-500 text-xs mt-1">{errors.nome_produto}</p>}
                    </div>
                    
                    <div>
                        <label htmlFor="unidade_medida_produto" className="block text-sm font-medium text-gray-700">Unidade de Medida</label>
                        <input type="text" name="unidade_medida_produto" id="unidade_medida_produto"
                            value={formData.unidade_medida_produto || ''}
                            onChange={handleChange}
                            className="mt-1 block w-full border border-gray-300 rounded-md shadow-sm p-2"
                        />
                        {errors.unidade_medida_produto && <p className="text-red-500 text-xs mt-1">{errors.unidade_medida_produto}</p>}
                    </div>

                    <div className="flex space-x-4">
                        <div className="flex-1">
                            <label htmlFor="estoque_minimo_produto" className="block text-sm font-medium text-gray-700">Estoque Mínimo</label>
                            <input type="number" name="estoque_minimo_produto" id="estoque_minimo_produto"
                                value={formData.estoque_minimo_produto || 1}
                                onChange={handleChange}
                                min="1"
                                className="mt-1 block w-full border border-gray-300 rounded-md shadow-sm p-2"
                            />
                            {errors.estoque_minimo_produto && <p className="text-red-500 text-xs mt-1">{errors.estoque_minimo_produto}</p>}
                        </div>
                        
                        {!isEdit && (
                            <div className="flex-1">
                                <label htmlFor="estoque_atual_produto" className="block text-sm font-medium text-gray-700">Estoque Inicial</label>
                                <input type="number" name="estoque_atual_produto" id="estoque_atual_produto"
                                    value={formData.estoque_atual_produto ?? 0}
                                    onChange={handleChange}
                                    min="0"
                                    className="mt-1 block w-full border border-gray-300 rounded-md shadow-sm p-2"
                                />
                                {errors.estoque_atual_produto && <p className="text-red-500 text-xs mt-1">{errors.estoque_atual_produto}</p>}
                            </div>
                        )}

                        {isEdit && (
                            <div className="flex-1">
                                <label className="block text-sm font-medium text-gray-700">Estoque Atual</label>
                                <p className="mt-1 block w-full border border-gray-300 bg-gray-100 rounded-md shadow-sm p-2 text-gray-600 font-semibold">
                                    {produtoData?.estoque_atual_produto || 0} {produtoData?.unidade_medida_produto || ''}
                                </p>
                                <p className="text-xs text-gray-500 mt-1">O estoque é atualizado via Movimentações.</p>
                            </div>
                        )}
                    </div>

                    <div>
                        <label htmlFor="descricao_produto" className="block text-sm font-medium text-gray-700">Descrição (Opcional)</label>
                        <textarea name="descricao_produto" id="descricao_produto"
                            value={formData.descricao_produto || ''}
                            onChange={handleChange}
                            rows="3"
                            className="mt-1 block w-full border border-gray-300 rounded-md shadow-sm p-2"
                        />
                    </div>

                    <div className="flex justify-end space-x-4 pt-4">
                        <button type="button" onClick={onClose} className="px-4 py-2 border rounded-lg text-gray-700 hover:bg-gray-100">Cancelar</button>
                        <button type="submit" className="px-4 py-2 text-white bg-blue-600 rounded-lg hover:bg-blue-700">Salvar</button>
                    </div>
                </form>
            </div>
        </div>
    );
};
// --- FIM do Componente Modal/Form ---

// -------------------------------------------------------------------
// --- Componente Produtos Principal ---
// -------------------------------------------------------------------

const Produtos = () => {
    const navigate = useNavigate();
    const [produtos, setProdutos] = useState([]);
    
    // 🟢 ESTADO PARA O INPUT (o que o usuário digita)
    const [inputTermoBusca, setInputTermoBusca] = useState(''); 
    // 🟢 ESTADO PARA O FILTRO ATIVO (o que dispara a requisição)
    const [filtroAtivo, setFiltroAtivo] = useState(''); 

    const [modalOpen, setModalOpen] = useState(false);
    const [produtoEmEdicao, setProdutoEmEdicao] = useState(null);
    const [error, setError] = useState(null);

    // MUDANÇA: Função buscarProdutos usa 'termo' (o filtroAtivo)
    const buscarProdutos = useCallback(async (termo) => {
        setError(null);
        try {
            const authApi = getAuthApi();
            
            // 🟢 CRIAÇÃO DA URL USANDO O PARÂMETRO 'search' (que a API espera agora)
            let url = 'produtos/';
            if (termo && termo.trim() !== '') {
                 // Usa o parâmetro 'search'
                url = `produtos/?search=${termo}`; 
            }

            const response = await authApi.get(url);
            setProdutos(response.data);
        } catch (err) {
            console.error('Erro ao buscar produtos:', err);
            if (err.response && err.response.status === 401) {
                setError("Sessão expirada. Por favor, faça login novamente.");
                localStorage.removeItem('accessToken');
                localStorage.removeItem('refreshToken');
            } else if (err.response && err.response.data) {
                setError(`Erro: ${Object.values(err.response.data).join(', ')}`);
            } else {
                setError("Erro ao carregar produtos. Verifique sua conexão ou tente novamente.");
            }
        }
    }, []);

    // MUDANÇA: useEffect só reage a mudanças no `filtroAtivo` (disparado pelo botão)
    useEffect(() => {
        buscarProdutos(filtroAtivo);
    }, [buscarProdutos, filtroAtivo]);

    // 🟢 NOVO: Função para aplicar o filtro (dispara a busca)
    const handleAplicarFiltro = () => {
        setFiltroAtivo(inputTermoBusca);
    };

    // 🟢 NOVO: Função para limpar o filtro
    const handleLimparFiltro = () => {
        setInputTermoBusca(''); 
        setFiltroAtivo(''); // Isso dispara o useEffect e busca tudo de novo
    };

    const handleExcluir = async (id) => {
        if (!window.confirm("Confirmar a exclusão deste produto?")) return;

        try {
            const authApi = getAuthApi();
            await authApi.delete(`produtos/${id}/`);
            // MUDANÇA: Passa o filtroAtivo para manter a busca após exclusão
            buscarProdutos(filtroAtivo); 
        } catch (error) {
            console.error('Erro ao excluir produto:', error);
            if (error.response && error.response.status === 401) {
                setError("Sessão expirada. Por favor, faça login novamente.");
                localStorage.removeItem('accessToken');
                localStorage.removeItem('refreshToken');
            } else if (error.response && error.response.data) {
                setError(`Erro ao excluir: ${Object.values(error.response.data).join(', ')}`);
            } else {
                setError('Erro ao excluir produto. Ele pode estar associado a movimentações ou houve um problema de conexão.');
            }
        }
    };

    const handleOpenModal = (produto = null) => {
        setProdutoEmEdicao(produto);
        setModalOpen(true);
    };

    const temEstoqueBaixo = produtos.some(p => p.estoque_atual_produto < p.estoque_minimo_produto);


    return (
        <div className="min-h-screen bg-gray-50">
            <Header /> 
            <div className="max-w-7xl mx-auto p-4 sm:p-6 lg:p-8">
                <button onClick={() => navigate('/')} className="mb-4 text-blue-600 hover:text-blue-800 font-semibold flex items-center">&larr; Voltar para Home</button>
                <h2 className="text-3xl font-bold text-gray-800 mb-6">Gestão de Produtos</h2>
                
                <div className="flex justify-between items-start mb-6 flex-wrap gap-4">
                    
                    <div className="flex items-center space-x-2 w-full max-w-lg">
                        <input 
                            type="text" 
                            placeholder="Buscar produto por nome ou descrição..." 
                            value={inputTermoBusca} 
                            onChange={(e) => setInputTermoBusca(e.target.value)}
                            onKeyDown={(e) => e.key === 'Enter' && handleAplicarFiltro()}
                            className="border border-gray-300 rounded-lg p-2 flex-1 focus:ring-blue-500" 
                        />
                        
                        <button 
                            onClick={handleAplicarFiltro}
                            className="px-4 py-2 text-white bg-blue-600 rounded-lg hover:bg-blue-700 transition duration-150 shadow-md"
                        >
                            Filtrar
                        </button>

                        {filtroAtivo && (
                            <button 
                                onClick={handleLimparFiltro}
                                className="p-2 text-gray-500 bg-gray-100 rounded-lg hover:bg-gray-200 transition duration-150"
                                title="Limpar Filtro"
                            >
                                <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5" viewBox="0 0 20 20" fill="currentColor">
                                    <path fillRule="evenodd" d="M4.293 4.293a1 1 0 011.414 0L10 8.586l4.293-4.293a1 1 0 111.414 1.414L11.414 10l4.293 4.293a1 1 0 01-1.414 1.414L10 11.414l-4.293 4.293a1 1 0 01-1.414-1.414L8.586 10 4.293 5.707a1 1 0 010-1.414z" clipRule="evenodd" />
                                </svg>
                            </button>
                        )}
                    </div>
                    
                    <button onClick={() => handleOpenModal(null)}
                        className="px-4 py-2 text-white bg-green-600 rounded-lg hover:bg-green-700 transition duration-150 shadow-md"
                    >
                        + Novo Produto
                    </button>
                </div>
                
                {error && <Alert message={error} type="error" className="mb-4" />}
                
                {temEstoqueBaixo && (
                    <Alert
                        message="Atenção: Existem produtos com estoque abaixo do nível mínimo. Verifique os itens destacados em vermelho na tabela."
                        type="stock-alert"
                        className="mb-4"
                    />
                )}

                <div className="overflow-x-auto bg-white shadow-lg rounded-xl">
                    <table className="min-w-full divide-y divide-gray-200">
                        <thead className="bg-gray-50">
                            <tr>
                                <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Produto</th>
                                <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Estoque Atual</th>
                                <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Estoque Mínimo</th>
                                <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Ações</th>
                            </tr>
                        </thead>
                        <tbody className="bg-white divide-y divide-gray-200">
                            {produtos.map(p => (
                                <tr
                                    key={p.id}
                                    className={p.estoque_atual_produto < p.estoque_minimo_produto ? 'bg-red-50 hover:bg-red-100' : 'hover:bg-gray-50'}
                                >
                                    <td className="px-6 py-4 whitespace-nowrap text-sm font-medium text-gray-900">{p.nome_produto}</td>
                                    <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500 font-bold">
                                        {p.estoque_atual_produto} {p.unidade_medida_produto}
                                    </td>
                                    <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">{p.estoque_minimo_produto} {p.unidade_medida_produto}</td>
                                    <td className="px-6 py-4 whitespace-nowrap text-sm font-medium">
                                        <button onClick={() => handleOpenModal(p)} className="text-blue-600 hover:text-blue-900 mr-4">Editar</button>
                                        <button onClick={() => handleExcluir(p.id)} className="text-red-600 hover:text-red-900">Excluir</button>
                                    </td>
                                </tr>
                            ))}
                        </tbody>
                    </table>
                </div>
            </div>

            <ProdutoFormModal 
                isOpen={modalOpen} 
                onClose={() => setModalOpen(false)} 
                produtoData={produtoEmEdicao}
                refetch={() => buscarProdutos(filtroAtivo)} 
            />
        </div>
    );
};

export default Produtos;