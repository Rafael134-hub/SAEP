import axios from 'axios';

const API_BASE_URL = 'http://localhost:8000/api/';


export const login = async (username, password) => {
    try {
        const response = await axios.post(`${API_BASE_URL}token/`, { username, password });
        localStorage.setItem('accessToken', response.data.access);
        localStorage.setItem('refreshToken', response.data.refresh);

        return response.data;
    } catch (error) {
        throw error;
    }
};


export const logout = () => {
    localStorage.removeItem('accessToken');
    localStorage.removeItem('refreshToken');
};


export const getAuthApi = () => {
    const accessToken = localStorage.getItem('accessToken');

    return axios.create({
        baseURL: API_BASE_URL,
        headers: {
            'Content-Type': 'application/json',
            Authorization: `Bearer ${accessToken}`,
        },
    });
};