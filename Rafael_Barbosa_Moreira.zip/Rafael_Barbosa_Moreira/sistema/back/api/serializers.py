from rest_framework import serializers
from django.contrib.auth.models import User
from .models import Produto, Movimentacao 

class UserSerializer(serializers.ModelSerializer):
    """
    Serializa os dados do usuário para a UserInfoView.
    """
    class Meta:
        model = User
        fields = ['id', 'username', 'first_name', 'last_name']

class ProdutoSerializer(serializers.ModelSerializer):
    """
    Serializa o modelo Produto.
    """
    class Meta:
        model = Produto
        fields = '__all__'


class MovimentacaoSerializer(serializers.ModelSerializer):
    
    produto_nome = serializers.CharField(source='produto_id.nome_produto', read_only=True)
    usuario_nome = serializers.CharField(source='usuario.username', read_only=True)
    
    produto = serializers.PrimaryKeyRelatedField(
        queryset=Produto.objects.all(),
        source='produto_id' 
    )

    class Meta:
        model = Movimentacao
        fields = [
            'id', 'produto', 'produto_nome', 'categoria_movimentacao', 
            'quantidade_movimentacao', 'data_movimentacao', 'usuario', 
            'usuario_nome', 'observacao_movimentacao'
        ]
        read_only_fields = ('usuario', 'data_movimentacao')
        
    def create(self, validated_data):
        validated_data.pop('produto_nome', None)
        validated_data.pop('usuario_nome', None)

        return Movimentacao.objects.create(**validated_data)


class SaidaMovimentacaoSerializer(MovimentacaoSerializer):
    alerta_estoque = serializers.CharField(read_only=True)

    class Meta(MovimentacaoSerializer.Meta):
        fields = MovimentacaoSerializer.Meta.fields + ['alerta_estoque']