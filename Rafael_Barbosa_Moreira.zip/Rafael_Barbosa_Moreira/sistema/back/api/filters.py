import django_filters
from django.db import models
from .models import Produto, Movimentacao 


class ProdutoFilter(django_filters.FilterSet):
    search = django_filters.CharFilter(method='filter_busca') 

    class Meta:
        model = Produto
        fields = ['search'] 

    def filter_busca(self, queryset, name, value):
        return queryset.filter(
            models.Q(nome_produto__icontains=value) | 
            models.Q(descricao_produto__icontains=value)
        )

class MovimentacaoFilter(django_filters.FilterSet):
    search = django_filters.CharFilter(method='filter_busca_produto') 

    class Meta:
        model = Movimentacao
        fields = ['search'] 

    def filter_busca_produto(self, queryset, name, value):
       
        return queryset.filter(
            models.Q(produto_id__nome_produto__icontains=value)
        )