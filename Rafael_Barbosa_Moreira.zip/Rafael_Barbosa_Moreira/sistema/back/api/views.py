from rest_framework import viewsets, status
from rest_framework.permissions import IsAuthenticated
from rest_framework.response import Response
from rest_framework.views import APIView
from rest_framework.exceptions import ValidationError
from django.db.models import F
from .models import Produto, Movimentacao
from .serializers import ProdutoSerializer, MovimentacaoSerializer, SaidaMovimentacaoSerializer, UserSerializer

from django_filters.rest_framework import DjangoFilterBackend
from .filters import ProdutoFilter, MovimentacaoFilter 

class ProdutoViewSet(viewsets.ModelViewSet):
    permission_classes = [IsAuthenticated]
    serializer_class = ProdutoSerializer
    
    filter_backends = [DjangoFilterBackend]
    filterset_class = ProdutoFilter 
    
    def get_queryset(self):
        return Produto.objects.all().order_by(F('nome_produto')) 

class MovimentacaoViewSet(viewsets.ModelViewSet):
    permission_classes = [IsAuthenticated]
    filter_backends = [DjangoFilterBackend]
    filterset_class = MovimentacaoFilter 
    
    def get_queryset(self):
        return Movimentacao.objects.all().select_related('produto_id', 'usuario').order_by('-data_movimentacao')

    def get_serializer_class(self):
        return MovimentacaoSerializer

    def create(self, request, *args, **kwargs):
        serializer = self.get_serializer(data=request.data)
        serializer.is_valid(raise_exception=True)

        data = serializer.validated_data
        
        produto = data.get('produto_id') 
        categoria_movimentacao = data.get('categoria_movimentacao')
        quantidade = data.get('quantidade_movimentacao')

        if categoria_movimentacao == 'SAIDA':
             if produto is None:
                  raise ValidationError({"produto": ["Produto não encontrado. ID inválido."]})

             if quantidade > produto.estoque_atual_produto:
                 raise ValidationError({
                     "quantidade_movimentacao": [f"Estoque insuficiente. O estoque atual de {produto.nome_produto} é {produto.estoque_atual_produto}."]
                 })
        
        movimentacao_instance = serializer.save(usuario=self.request.user)
        produto.refresh_from_db() 
        
        alerta = None

        if produto.estoque_atual_produto <= produto.estoque_minimo_produto:
            alerta = f"ALERTA: O estoque de {produto.nome_produto} atingiu o nível crítico ({produto.estoque_atual_produto} em estoque, mínimo é {produto.estoque_minimo_produto})."
        
        if alerta:
            response_serializer = SaidaMovimentacaoSerializer(movimentacao_instance)
            data = response_serializer.data
            data['alerta_estoque'] = alerta
            return Response(data, status=status.HTTP_201_CREATED)
        
        return Response(serializer.data, status=status.HTTP_201_CREATED)

class UserInfoView(APIView):
    permission_classes = [IsAuthenticated]

    def get(self, request):
        serializer = UserSerializer(request.user)
        return Response(serializer.data)